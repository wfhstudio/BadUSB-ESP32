#pragma once
#define Arrow_Right_width 4
#define Arrow_Right_height 7
#define Arrow_Right_x_hot 122
#define Arrow_Right_y_hot 56
static unsigned char Arrow_Right_bits[] = {
   0x01, 0x03, 0x07, 0x0f, 0x07, 0x03, 0x01 };