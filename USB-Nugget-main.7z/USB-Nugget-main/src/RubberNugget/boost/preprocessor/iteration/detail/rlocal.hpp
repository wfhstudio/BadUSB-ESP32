# /* **************************************************************************
#  *                                                                          *
#  *     (C) Copyright Paul Mensonides 2002.
#  *     Distributed under the Boost Software License, Version 1.0. (See
#  *     accompanying file LICENSE_1_0.txt or copy at
#  *     http://www.boost.org/LICENSE_1_0.txt)
#  *                                                                          *
#  ************************************************************************** */
#
# /* Revised by Edward Diener (2020) */
#
# /* See http://www.boost.org for most recent version. */
#
# include <boost/preprocessor/config/config.hpp>
#
# if ~BOOST_PP_CONFIG_FLAGS() & BOOST_PP_CONFIG_STRICT()
#
# if BOOST_PP_LOCAL_R(256)
    BOOST_PP_LOCAL_MACRO(256)
# endif
# if BOOST_PP_LOCAL_R(255)
    BOOST_PP_LOCAL_MACRO(255)
# endif
# if BOOST_PP_LOCAL_R(254)
    BOOST_PP_LOCAL_MACRO(254)
# endif
# if BOOST_PP_LOCAL_R(253)
    BOOST_PP_LOCAL_MACRO(253)
# endif
# if BOOST_PP_LOCAL_R(252)
    BOOST_PP_LOCAL_MACRO(252)
# endif
# if BOOST_PP_LOCAL_R(251)
    BOOST_PP_LOCAL_MACRO(251)
# endif
# if BOOST_PP_LOCAL_R(250)
    BOOST_PP_LOCAL_MACRO(250)
# endif
# if BOOST_PP_LOCAL_R(249)
    BOOST_PP_LOCAL_MACRO(249)
# endif
# if BOOST_PP_LOCAL_R(248)
    BOOST_PP_LOCAL_MACRO(248)
# endif
# if BOOST_PP_LOCAL_R(247)
    BOOST_PP_LOCAL_MACRO(247)
# endif
# if BOOST_PP_LOCAL_R(246)
    BOOST_PP_LOCAL_MACRO(246)
# endif
# if BOOST_PP_LOCAL_R(245)
    BOOST_PP_LOCAL_MACRO(245)
# endif
# if BOOST_PP_LOCAL_R(244)
    BOOST_PP_LOCAL_MACRO(244)
# endif
# if BOOST_PP_LOCAL_R(243)
    BOOST_PP_LOCAL_MACRO(243)
# endif
# if BOOST_PP_LOCAL_R(242)
    BOOST_PP_LOCAL_MACRO(242)
# endif
# if BOOST_PP_LOCAL_R(241)
    BOOST_PP_LOCAL_MACRO(241)
# endif
# if BOOST_PP_LOCAL_R(240)
    BOOST_PP_LOCAL_MACRO(240)
# endif
# if BOOST_PP_LOCAL_R(239)
    BOOST_PP_LOCAL_MACRO(239)
# endif
# if BOOST_PP_LOCAL_R(238)
    BOOST_PP_LOCAL_MACRO(238)
# endif
# if BOOST_PP_LOCAL_R(237)
    BOOST_PP_LOCAL_MACRO(237)
# endif
# if BOOST_PP_LOCAL_R(236)
    BOOST_PP_LOCAL_MACRO(236)
# endif
# if BOOST_PP_LOCAL_R(235)
    BOOST_PP_LOCAL_MACRO(235)
# endif
# if BOOST_PP_LOCAL_R(234)
    BOOST_PP_LOCAL_MACRO(234)
# endif
# if BOOST_PP_LOCAL_R(233)
    BOOST_PP_LOCAL_MACRO(233)
# endif
# if BOOST_PP_LOCAL_R(232)
    BOOST_PP_LOCAL_MACRO(232)
# endif
# if BOOST_PP_LOCAL_R(231)
    BOOST_PP_LOCAL_MACRO(231)
# endif
# if BOOST_PP_LOCAL_R(230)
    BOOST_PP_LOCAL_MACRO(230)
# endif
# if BOOST_PP_LOCAL_R(229)
    BOOST_PP_LOCAL_MACRO(229)
# endif
# if BOOST_PP_LOCAL_R(228)
    BOOST_PP_LOCAL_MACRO(228)
# endif
# if BOOST_PP_LOCAL_R(227)
    BOOST_PP_LOCAL_MACRO(227)
# endif
# if BOOST_PP_LOCAL_R(226)
    BOOST_PP_LOCAL_MACRO(226)
# endif
# if BOOST_PP_LOCAL_R(225)
    BOOST_PP_LOCAL_MACRO(225)
# endif
# if BOOST_PP_LOCAL_R(224)
    BOOST_PP_LOCAL_MACRO(224)
# endif
# if BOOST_PP_LOCAL_R(223)
    BOOST_PP_LOCAL_MACRO(223)
# endif
# if BOOST_PP_LOCAL_R(222)
    BOOST_PP_LOCAL_MACRO(222)
# endif
# if BOOST_PP_LOCAL_R(221)
    BOOST_PP_LOCAL_MACRO(221)
# endif
# if BOOST_PP_LOCAL_R(220)
    BOOST_PP_LOCAL_MACRO(220)
# endif
# if BOOST_PP_LOCAL_R(219)
    BOOST_PP_LOCAL_MACRO(219)
# endif
# if BOOST_PP_LOCAL_R(218)
    BOOST_PP_LOCAL_MACRO(218)
# endif
# if BOOST_PP_LOCAL_R(217)
    BOOST_PP_LOCAL_MACRO(217)
# endif
# if BOOST_PP_LOCAL_R(216)
    BOOST_PP_LOCAL_MACRO(216)
# endif
# if BOOST_PP_LOCAL_R(215)
    BOOST_PP_LOCAL_MACRO(215)
# endif
# if BOOST_PP_LOCAL_R(214)
    BOOST_PP_LOCAL_MACRO(214)
# endif
# if BOOST_PP_LOCAL_R(213)
    BOOST_PP_LOCAL_MACRO(213)
# endif
# if BOOST_PP_LOCAL_R(212)
    BOOST_PP_LOCAL_MACRO(212)
# endif
# if BOOST_PP_LOCAL_R(211)
    BOOST_PP_LOCAL_MACRO(211)
# endif
# if BOOST_PP_LOCAL_R(210)
    BOOST_PP_LOCAL_MACRO(210)
# endif
# if BOOST_PP_LOCAL_R(209)
    BOOST_PP_LOCAL_MACRO(209)
# endif
# if BOOST_PP_LOCAL_R(208)
    BOOST_PP_LOCAL_MACRO(208)
# endif
# if BOOST_PP_LOCAL_R(207)
    BOOST_PP_LOCAL_MACRO(207)
# endif
# if BOOST_PP_LOCAL_R(206)
    BOOST_PP_LOCAL_MACRO(206)
# endif
# if BOOST_PP_LOCAL_R(205)
    BOOST_PP_LOCAL_MACRO(205)
# endif
# if BOOST_PP_LOCAL_R(204)
    BOOST_PP_LOCAL_MACRO(204)
# endif
# if BOOST_PP_LOCAL_R(203)
    BOOST_PP_LOCAL_MACRO(203)
# endif
# if BOOST_PP_LOCAL_R(202)
    BOOST_PP_LOCAL_MACRO(202)
# endif
# if BOOST_PP_LOCAL_R(201)
    BOOST_PP_LOCAL_MACRO(201)
# endif
# if BOOST_PP_LOCAL_R(200)
    BOOST_PP_LOCAL_MACRO(200)
# endif
# if BOOST_PP_LOCAL_R(199)
    BOOST_PP_LOCAL_MACRO(199)
# endif
# if BOOST_PP_LOCAL_R(198)
    BOOST_PP_LOCAL_MACRO(198)
# endif
# if BOOST_PP_LOCAL_R(197)
    BOOST_PP_LOCAL_MACRO(197)
# endif
# if BOOST_PP_LOCAL_R(196)
    BOOST_PP_LOCAL_MACRO(196)
# endif
# if BOOST_PP_LOCAL_R(195)
    BOOST_PP_LOCAL_MACRO(195)
# endif
# if BOOST_PP_LOCAL_R(194)
    BOOST_PP_LOCAL_MACRO(194)
# endif
# if BOOST_PP_LOCAL_R(193)
    BOOST_PP_LOCAL_MACRO(193)
# endif
# if BOOST_PP_LOCAL_R(192)
    BOOST_PP_LOCAL_MACRO(192)
# endif
# if BOOST_PP_LOCAL_R(191)
    BOOST_PP_LOCAL_MACRO(191)
# endif
# if BOOST_PP_LOCAL_R(190)
    BOOST_PP_LOCAL_MACRO(190)
# endif
# if BOOST_PP_LOCAL_R(189)
    BOOST_PP_LOCAL_MACRO(189)
# endif
# if BOOST_PP_LOCAL_R(188)
    BOOST_PP_LOCAL_MACRO(188)
# endif
# if BOOST_PP_LOCAL_R(187)
    BOOST_PP_LOCAL_MACRO(187)
# endif
# if BOOST_PP_LOCAL_R(186)
    BOOST_PP_LOCAL_MACRO(186)
# endif
# if BOOST_PP_LOCAL_R(185)
    BOOST_PP_LOCAL_MACRO(185)
# endif
# if BOOST_PP_LOCAL_R(184)
    BOOST_PP_LOCAL_MACRO(184)
# endif
# if BOOST_PP_LOCAL_R(183)
    BOOST_PP_LOCAL_MACRO(183)
# endif
# if BOOST_PP_LOCAL_R(182)
    BOOST_PP_LOCAL_MACRO(182)
# endif
# if BOOST_PP_LOCAL_R(181)
    BOOST_PP_LOCAL_MACRO(181)
# endif
# if BOOST_PP_LOCAL_R(180)
    BOOST_PP_LOCAL_MACRO(180)
# endif
# if BOOST_PP_LOCAL_R(179)
    BOOST_PP_LOCAL_MACRO(179)
# endif
# if BOOST_PP_LOCAL_R(178)
    BOOST_PP_LOCAL_MACRO(178)
# endif
# if BOOST_PP_LOCAL_R(177)
    BOOST_PP_LOCAL_MACRO(177)
# endif
# if BOOST_PP_LOCAL_R(176)
    BOOST_PP_LOCAL_MACRO(176)
# endif
# if BOOST_PP_LOCAL_R(175)
    BOOST_PP_LOCAL_MACRO(175)
# endif
# if BOOST_PP_LOCAL_R(174)
    BOOST_PP_LOCAL_MACRO(174)
# endif
# if BOOST_PP_LOCAL_R(173)
    BOOST_PP_LOCAL_MACRO(173)
# endif
# if BOOST_PP_LOCAL_R(172)
    BOOST_PP_LOCAL_MACRO(172)
# endif
# if BOOST_PP_LOCAL_R(171)
    BOOST_PP_LOCAL_MACRO(171)
# endif
# if BOOST_PP_LOCAL_R(170)
    BOOST_PP_LOCAL_MACRO(170)
# endif
# if BOOST_PP_LOCAL_R(169)
    BOOST_PP_LOCAL_MACRO(169)
# endif
# if BOOST_PP_LOCAL_R(168)
    BOOST_PP_LOCAL_MACRO(168)
# endif
# if BOOST_PP_LOCAL_R(167)
    BOOST_PP_LOCAL_MACRO(167)
# endif
# if BOOST_PP_LOCAL_R(166)
    BOOST_PP_LOCAL_MACRO(166)
# endif
# if BOOST_PP_LOCAL_R(165)
    BOOST_PP_LOCAL_MACRO(165)
# endif
# if BOOST_PP_LOCAL_R(164)
    BOOST_PP_LOCAL_MACRO(164)
# endif
# if BOOST_PP_LOCAL_R(163)
    BOOST_PP_LOCAL_MACRO(163)
# endif
# if BOOST_PP_LOCAL_R(162)
    BOOST_PP_LOCAL_MACRO(162)
# endif
# if BOOST_PP_LOCAL_R(161)
    BOOST_PP_LOCAL_MACRO(161)
# endif
# if BOOST_PP_LOCAL_R(160)
    BOOST_PP_LOCAL_MACRO(160)
# endif
# if BOOST_PP_LOCAL_R(159)
    BOOST_PP_LOCAL_MACRO(159)
# endif
# if BOOST_PP_LOCAL_R(158)
    BOOST_PP_LOCAL_MACRO(158)
# endif
# if BOOST_PP_LOCAL_R(157)
    BOOST_PP_LOCAL_MACRO(157)
# endif
# if BOOST_PP_LOCAL_R(156)
    BOOST_PP_LOCAL_MACRO(156)
# endif
# if BOOST_PP_LOCAL_R(155)
    BOOST_PP_LOCAL_MACRO(155)
# endif
# if BOOST_PP_LOCAL_R(154)
    BOOST_PP_LOCAL_MACRO(154)
# endif
# if BOOST_PP_LOCAL_R(153)
    BOOST_PP_LOCAL_MACRO(153)
# endif
# if BOOST_PP_LOCAL_R(152)
    BOOST_PP_LOCAL_MACRO(152)
# endif
# if BOOST_PP_LOCAL_R(151)
    BOOST_PP_LOCAL_MACRO(151)
# endif
# if BOOST_PP_LOCAL_R(150)
    BOOST_PP_LOCAL_MACRO(150)
# endif
# if BOOST_PP_LOCAL_R(149)
    BOOST_PP_LOCAL_MACRO(149)
# endif
# if BOOST_PP_LOCAL_R(148)
    BOOST_PP_LOCAL_MACRO(148)
# endif
# if BOOST_PP_LOCAL_R(147)
    BOOST_PP_LOCAL_MACRO(147)
# endif
# if BOOST_PP_LOCAL_R(146)
    BOOST_PP_LOCAL_MACRO(146)
# endif
# if BOOST_PP_LOCAL_R(145)
    BOOST_PP_LOCAL_MACRO(145)
# endif
# if BOOST_PP_LOCAL_R(144)
    BOOST_PP_LOCAL_MACRO(144)
# endif
# if BOOST_PP_LOCAL_R(143)
    BOOST_PP_LOCAL_MACRO(143)
# endif
# if BOOST_PP_LOCAL_R(142)
    BOOST_PP_LOCAL_MACRO(142)
# endif
# if BOOST_PP_LOCAL_R(141)
    BOOST_PP_LOCAL_MACRO(141)
# endif
# if BOOST_PP_LOCAL_R(140)
    BOOST_PP_LOCAL_MACRO(140)
# endif
# if BOOST_PP_LOCAL_R(139)
    BOOST_PP_LOCAL_MACRO(139)
# endif
# if BOOST_PP_LOCAL_R(138)
    BOOST_PP_LOCAL_MACRO(138)
# endif
# if BOOST_PP_LOCAL_R(137)
    BOOST_PP_LOCAL_MACRO(137)
# endif
# if BOOST_PP_LOCAL_R(136)
    BOOST_PP_LOCAL_MACRO(136)
# endif
# if BOOST_PP_LOCAL_R(135)
    BOOST_PP_LOCAL_MACRO(135)
# endif
# if BOOST_PP_LOCAL_R(134)
    BOOST_PP_LOCAL_MACRO(134)
# endif
# if BOOST_PP_LOCAL_R(133)
    BOOST_PP_LOCAL_MACRO(133)
# endif
# if BOOST_PP_LOCAL_R(132)
    BOOST_PP_LOCAL_MACRO(132)
# endif
# if BOOST_PP_LOCAL_R(131)
    BOOST_PP_LOCAL_MACRO(131)
# endif
# if BOOST_PP_LOCAL_R(130)
    BOOST_PP_LOCAL_MACRO(130)
# endif
# if BOOST_PP_LOCAL_R(129)
    BOOST_PP_LOCAL_MACRO(129)
# endif
# if BOOST_PP_LOCAL_R(128)
    BOOST_PP_LOCAL_MACRO(128)
# endif
# if BOOST_PP_LOCAL_R(127)
    BOOST_PP_LOCAL_MACRO(127)
# endif
# if BOOST_PP_LOCAL_R(126)
    BOOST_PP_LOCAL_MACRO(126)
# endif
# if BOOST_PP_LOCAL_R(125)
    BOOST_PP_LOCAL_MACRO(125)
# endif
# if BOOST_PP_LOCAL_R(124)
    BOOST_PP_LOCAL_MACRO(124)
# endif
# if BOOST_PP_LOCAL_R(123)
    BOOST_PP_LOCAL_MACRO(123)
# endif
# if BOOST_PP_LOCAL_R(122)
    BOOST_PP_LOCAL_MACRO(122)
# endif
# if BOOST_PP_LOCAL_R(121)
    BOOST_PP_LOCAL_MACRO(121)
# endif
# if BOOST_PP_LOCAL_R(120)
    BOOST_PP_LOCAL_MACRO(120)
# endif
# if BOOST_PP_LOCAL_R(119)
    BOOST_PP_LOCAL_MACRO(119)
# endif
# if BOOST_PP_LOCAL_R(118)
    BOOST_PP_LOCAL_MACRO(118)
# endif
# if BOOST_PP_LOCAL_R(117)
    BOOST_PP_LOCAL_MACRO(117)
# endif
# if BOOST_PP_LOCAL_R(116)
    BOOST_PP_LOCAL_MACRO(116)
# endif
# if BOOST_PP_LOCAL_R(115)
    BOOST_PP_LOCAL_MACRO(115)
# endif
# if BOOST_PP_LOCAL_R(114)
    BOOST_PP_LOCAL_MACRO(114)
# endif
# if BOOST_PP_LOCAL_R(113)
    BOOST_PP_LOCAL_MACRO(113)
# endif
# if BOOST_PP_LOCAL_R(112)
    BOOST_PP_LOCAL_MACRO(112)
# endif
# if BOOST_PP_LOCAL_R(111)
    BOOST_PP_LOCAL_MACRO(111)
# endif
# if BOOST_PP_LOCAL_R(110)
    BOOST_PP_LOCAL_MACRO(110)
# endif
# if BOOST_PP_LOCAL_R(109)
    BOOST_PP_LOCAL_MACRO(109)
# endif
# if BOOST_PP_LOCAL_R(108)
    BOOST_PP_LOCAL_MACRO(108)
# endif
# if BOOST_PP_LOCAL_R(107)
    BOOST_PP_LOCAL_MACRO(107)
# endif
# if BOOST_PP_LOCAL_R(106)
    BOOST_PP_LOCAL_MACRO(106)
# endif
# if BOOST_PP_LOCAL_R(105)
    BOOST_PP_LOCAL_MACRO(105)
# endif
# if BOOST_PP_LOCAL_R(104)
    BOOST_PP_LOCAL_MACRO(104)
# endif
# if BOOST_PP_LOCAL_R(103)
    BOOST_PP_LOCAL_MACRO(103)
# endif
# if BOOST_PP_LOCAL_R(102)
    BOOST_PP_LOCAL_MACRO(102)
# endif
# if BOOST_PP_LOCAL_R(101)
    BOOST_PP_LOCAL_MACRO(101)
# endif
# if BOOST_PP_LOCAL_R(100)
    BOOST_PP_LOCAL_MACRO(100)
# endif
# if BOOST_PP_LOCAL_R(99)
    BOOST_PP_LOCAL_MACRO(99)
# endif
# if BOOST_PP_LOCAL_R(98)
    BOOST_PP_LOCAL_MACRO(98)
# endif
# if BOOST_PP_LOCAL_R(97)
    BOOST_PP_LOCAL_MACRO(97)
# endif
# if BOOST_PP_LOCAL_R(96)
    BOOST_PP_LOCAL_MACRO(96)
# endif
# if BOOST_PP_LOCAL_R(95)
    BOOST_PP_LOCAL_MACRO(95)
# endif
# if BOOST_PP_LOCAL_R(94)
    BOOST_PP_LOCAL_MACRO(94)
# endif
# if BOOST_PP_LOCAL_R(93)
    BOOST_PP_LOCAL_MACRO(93)
# endif
# if BOOST_PP_LOCAL_R(92)
    BOOST_PP_LOCAL_MACRO(92)
# endif
# if BOOST_PP_LOCAL_R(91)
    BOOST_PP_LOCAL_MACRO(91)
# endif
# if BOOST_PP_LOCAL_R(90)
    BOOST_PP_LOCAL_MACRO(90)
# endif
# if BOOST_PP_LOCAL_R(89)
    BOOST_PP_LOCAL_MACRO(89)
# endif
# if BOOST_PP_LOCAL_R(88)
    BOOST_PP_LOCAL_MACRO(88)
# endif
# if BOOST_PP_LOCAL_R(87)
    BOOST_PP_LOCAL_MACRO(87)
# endif
# if BOOST_PP_LOCAL_R(86)
    BOOST_PP_LOCAL_MACRO(86)
# endif
# if BOOST_PP_LOCAL_R(85)
    BOOST_PP_LOCAL_MACRO(85)
# endif
# if BOOST_PP_LOCAL_R(84)
    BOOST_PP_LOCAL_MACRO(84)
# endif
# if BOOST_PP_LOCAL_R(83)
    BOOST_PP_LOCAL_MACRO(83)
# endif
# if BOOST_PP_LOCAL_R(82)
    BOOST_PP_LOCAL_MACRO(82)
# endif
# if BOOST_PP_LOCAL_R(81)
    BOOST_PP_LOCAL_MACRO(81)
# endif
# if BOOST_PP_LOCAL_R(80)
    BOOST_PP_LOCAL_MACRO(80)
# endif
# if BOOST_PP_LOCAL_R(79)
    BOOST_PP_LOCAL_MACRO(79)
# endif
# if BOOST_PP_LOCAL_R(78)
    BOOST_PP_LOCAL_MACRO(78)
# endif
# if BOOST_PP_LOCAL_R(77)
    BOOST_PP_LOCAL_MACRO(77)
# endif
# if BOOST_PP_LOCAL_R(76)
    BOOST_PP_LOCAL_MACRO(76)
# endif
# if BOOST_PP_LOCAL_R(75)
    BOOST_PP_LOCAL_MACRO(75)
# endif
# if BOOST_PP_LOCAL_R(74)
    BOOST_PP_LOCAL_MACRO(74)
# endif
# if BOOST_PP_LOCAL_R(73)
    BOOST_PP_LOCAL_MACRO(73)
# endif
# if BOOST_PP_LOCAL_R(72)
    BOOST_PP_LOCAL_MACRO(72)
# endif
# if BOOST_PP_LOCAL_R(71)
    BOOST_PP_LOCAL_MACRO(71)
# endif
# if BOOST_PP_LOCAL_R(70)
    BOOST_PP_LOCAL_MACRO(70)
# endif
# if BOOST_PP_LOCAL_R(69)
    BOOST_PP_LOCAL_MACRO(69)
# endif
# if BOOST_PP_LOCAL_R(68)
    BOOST_PP_LOCAL_MACRO(68)
# endif
# if BOOST_PP_LOCAL_R(67)
    BOOST_PP_LOCAL_MACRO(67)
# endif
# if BOOST_PP_LOCAL_R(66)
    BOOST_PP_LOCAL_MACRO(66)
# endif
# if BOOST_PP_LOCAL_R(65)
    BOOST_PP_LOCAL_MACRO(65)
# endif
# if BOOST_PP_LOCAL_R(64)
    BOOST_PP_LOCAL_MACRO(64)
# endif
# if BOOST_PP_LOCAL_R(63)
    BOOST_PP_LOCAL_MACRO(63)
# endif
# if BOOST_PP_LOCAL_R(62)
    BOOST_PP_LOCAL_MACRO(62)
# endif
# if BOOST_PP_LOCAL_R(61)
    BOOST_PP_LOCAL_MACRO(61)
# endif
# if BOOST_PP_LOCAL_R(60)
    BOOST_PP_LOCAL_MACRO(60)
# endif
# if BOOST_PP_LOCAL_R(59)
    BOOST_PP_LOCAL_MACRO(59)
# endif
# if BOOST_PP_LOCAL_R(58)
    BOOST_PP_LOCAL_MACRO(58)
# endif
# if BOOST_PP_LOCAL_R(57)
    BOOST_PP_LOCAL_MACRO(57)
# endif
# if BOOST_PP_LOCAL_R(56)
    BOOST_PP_LOCAL_MACRO(56)
# endif
# if BOOST_PP_LOCAL_R(55)
    BOOST_PP_LOCAL_MACRO(55)
# endif
# if BOOST_PP_LOCAL_R(54)
    BOOST_PP_LOCAL_MACRO(54)
# endif
# if BOOST_PP_LOCAL_R(53)
    BOOST_PP_LOCAL_MACRO(53)
# endif
# if BOOST_PP_LOCAL_R(52)
    BOOST_PP_LOCAL_MACRO(52)
# endif
# if BOOST_PP_LOCAL_R(51)
    BOOST_PP_LOCAL_MACRO(51)
# endif
# if BOOST_PP_LOCAL_R(50)
    BOOST_PP_LOCAL_MACRO(50)
# endif
# if BOOST_PP_LOCAL_R(49)
    BOOST_PP_LOCAL_MACRO(49)
# endif
# if BOOST_PP_LOCAL_R(48)
    BOOST_PP_LOCAL_MACRO(48)
# endif
# if BOOST_PP_LOCAL_R(47)
    BOOST_PP_LOCAL_MACRO(47)
# endif
# if BOOST_PP_LOCAL_R(46)
    BOOST_PP_LOCAL_MACRO(46)
# endif
# if BOOST_PP_LOCAL_R(45)
    BOOST_PP_LOCAL_MACRO(45)
# endif
# if BOOST_PP_LOCAL_R(44)
    BOOST_PP_LOCAL_MACRO(44)
# endif
# if BOOST_PP_LOCAL_R(43)
    BOOST_PP_LOCAL_MACRO(43)
# endif
# if BOOST_PP_LOCAL_R(42)
    BOOST_PP_LOCAL_MACRO(42)
# endif
# if BOOST_PP_LOCAL_R(41)
    BOOST_PP_LOCAL_MACRO(41)
# endif
# if BOOST_PP_LOCAL_R(40)
    BOOST_PP_LOCAL_MACRO(40)
# endif
# if BOOST_PP_LOCAL_R(39)
    BOOST_PP_LOCAL_MACRO(39)
# endif
# if BOOST_PP_LOCAL_R(38)
    BOOST_PP_LOCAL_MACRO(38)
# endif
# if BOOST_PP_LOCAL_R(37)
    BOOST_PP_LOCAL_MACRO(37)
# endif
# if BOOST_PP_LOCAL_R(36)
    BOOST_PP_LOCAL_MACRO(36)
# endif
# if BOOST_PP_LOCAL_R(35)
    BOOST_PP_LOCAL_MACRO(35)
# endif
# if BOOST_PP_LOCAL_R(34)
    BOOST_PP_LOCAL_MACRO(34)
# endif
# if BOOST_PP_LOCAL_R(33)
    BOOST_PP_LOCAL_MACRO(33)
# endif
# if BOOST_PP_LOCAL_R(32)
    BOOST_PP_LOCAL_MACRO(32)
# endif
# if BOOST_PP_LOCAL_R(31)
    BOOST_PP_LOCAL_MACRO(31)
# endif
# if BOOST_PP_LOCAL_R(30)
    BOOST_PP_LOCAL_MACRO(30)
# endif
# if BOOST_PP_LOCAL_R(29)
    BOOST_PP_LOCAL_MACRO(29)
# endif
# if BOOST_PP_LOCAL_R(28)
    BOOST_PP_LOCAL_MACRO(28)
# endif
# if BOOST_PP_LOCAL_R(27)
    BOOST_PP_LOCAL_MACRO(27)
# endif
# if BOOST_PP_LOCAL_R(26)
    BOOST_PP_LOCAL_MACRO(26)
# endif
# if BOOST_PP_LOCAL_R(25)
    BOOST_PP_LOCAL_MACRO(25)
# endif
# if BOOST_PP_LOCAL_R(24)
    BOOST_PP_LOCAL_MACRO(24)
# endif
# if BOOST_PP_LOCAL_R(23)
    BOOST_PP_LOCAL_MACRO(23)
# endif
# if BOOST_PP_LOCAL_R(22)
    BOOST_PP_LOCAL_MACRO(22)
# endif
# if BOOST_PP_LOCAL_R(21)
    BOOST_PP_LOCAL_MACRO(21)
# endif
# if BOOST_PP_LOCAL_R(20)
    BOOST_PP_LOCAL_MACRO(20)
# endif
# if BOOST_PP_LOCAL_R(19)
    BOOST_PP_LOCAL_MACRO(19)
# endif
# if BOOST_PP_LOCAL_R(18)
    BOOST_PP_LOCAL_MACRO(18)
# endif
# if BOOST_PP_LOCAL_R(17)
    BOOST_PP_LOCAL_MACRO(17)
# endif
# if BOOST_PP_LOCAL_R(16)
    BOOST_PP_LOCAL_MACRO(16)
# endif
# if BOOST_PP_LOCAL_R(15)
    BOOST_PP_LOCAL_MACRO(15)
# endif
# if BOOST_PP_LOCAL_R(14)
    BOOST_PP_LOCAL_MACRO(14)
# endif
# if BOOST_PP_LOCAL_R(13)
    BOOST_PP_LOCAL_MACRO(13)
# endif
# if BOOST_PP_LOCAL_R(12)
    BOOST_PP_LOCAL_MACRO(12)
# endif
# if BOOST_PP_LOCAL_R(11)
    BOOST_PP_LOCAL_MACRO(11)
# endif
# if BOOST_PP_LOCAL_R(10)
    BOOST_PP_LOCAL_MACRO(10)
# endif
# if BOOST_PP_LOCAL_R(9)
    BOOST_PP_LOCAL_MACRO(9)
# endif
# if BOOST_PP_LOCAL_R(8)
    BOOST_PP_LOCAL_MACRO(8)
# endif
# if BOOST_PP_LOCAL_R(7)
    BOOST_PP_LOCAL_MACRO(7)
# endif
# if BOOST_PP_LOCAL_R(6)
    BOOST_PP_LOCAL_MACRO(6)
# endif
# if BOOST_PP_LOCAL_R(5)
    BOOST_PP_LOCAL_MACRO(5)
# endif
# if BOOST_PP_LOCAL_R(4)
    BOOST_PP_LOCAL_MACRO(4)
# endif
# if BOOST_PP_LOCAL_R(3)
    BOOST_PP_LOCAL_MACRO(3)
# endif
# if BOOST_PP_LOCAL_R(2)
    BOOST_PP_LOCAL_MACRO(2)
# endif
# if BOOST_PP_LOCAL_R(1)
    BOOST_PP_LOCAL_MACRO(1)
# endif
# if BOOST_PP_LOCAL_R(0)
    BOOST_PP_LOCAL_MACRO(0)
# endif
#
# else
#
# include <boost/preprocessor/config/limits.hpp>
#
# if BOOST_PP_LIMIT_ITERATION == 256
# include <boost/preprocessor/iteration/detail/limits/rlocal_256.hpp>
# elif BOOST_PP_LIMIT_ITERATION == 512
# include <boost/preprocessor/iteration/detail/limits/rlocal_512.hpp>
# include <boost/preprocessor/iteration/detail/limits/rlocal_256.hpp>
# elif BOOST_PP_LIMIT_ITERATION == 1024
# include <boost/preprocessor/iteration/detail/limits/rlocal_1024.hpp>
# include <boost/preprocessor/iteration/detail/limits/rlocal_512.hpp>
# include <boost/preprocessor/iteration/detail/limits/rlocal_256.hpp>
# else
# error Incorrect value for the BOOST_PP_LIMIT_ITERATION limit
# endif
#
# endif
