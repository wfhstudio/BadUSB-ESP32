#pragma once
#define Arrow_Left_width 4
#define Arrow_Left_height 7
#define Arrow_Left_x_hot 2
#define Arrow_Left_y_hot 56
static unsigned char Arrow_Left_bits[] = {
   0x08, 0x0c, 0x0e, 0x0f, 0x0e, 0x0c, 0x08 };